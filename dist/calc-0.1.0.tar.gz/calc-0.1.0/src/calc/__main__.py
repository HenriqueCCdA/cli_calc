from calc.cli import app

app()
